﻿namespace Trucks.Data;

public static class Configuration
{
    public static string ConnectionString = 
        @"Server=.;Database=Trucks;Integrated security=True;Encrypt=False";
}